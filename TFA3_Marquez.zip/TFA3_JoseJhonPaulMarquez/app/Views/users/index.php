<?= view('layouts/header', ['title' => 'Staff | Jose Jhon Paul Marquez', 'active' => 'users']) ?>
<section class="page-heading"><div><p class="eyebrow">THE PEOPLE BEHIND IT / 03</p><h1>Meet the team.</h1><p class="intro">An overview of the people and roles that keep the shop running.</p></div></section>
<section class="card data-card" aria-labelledby="staff-heading">
    <div class="table-heading"><p class="eyebrow">DATABASE RECORDS</p><h2 id="staff-heading">Staff accounts <span class="count"><?= count($users) ?></span></h2><p>Account usernames, full names, and assigned roles.</p></div>
    <?php if ($users === []): ?>
        <div class="empty-state" role="status"><h3>No staff accounts yet.</h3><p>Staff records will appear here after you add them to the database.</p></div>
    <?php else: ?>
        <div class="table-wrap" tabindex="0" role="region" aria-label="Staff accounts">
            <table><caption class="sr-only">Staff account records</caption><thead><tr><th scope="col">Username</th><th scope="col">Full name</th><th scope="col">Role</th></tr></thead>
            <tbody><?php foreach ($users as $user): ?><tr><td class="record-id">@<?= esc($user['username']) ?></td><th scope="row"><?= esc($user['full_name']) ?></th><td><span class="status status--progress"><?= esc($user['role']) ?></span></td></tr><?php endforeach ?></tbody></table>
        </div>
    <?php endif ?>
</section>
<?= view('layouts/footer') ?>
