# Jose Jhon Paul Marquez | POS Directory

A CodeIgniter 4 project for browsing customer and staff accounts stored in MySQL. The site uses a navy and lime interface throughout. The five customer and five staff records in the SQL file are fictional demonstration data; the email addresses use example.com and the phone numbers are placeholders.

## Start locally

1. Extract the ZIP and open the `TFA3_JoseJhonPaulMarquez` folder. The ZIP includes `vendor/` and a `.env` with local development defaults. PHP 8.2 or newer with `intl`, `mbstring`, and `mysqli` extensions is required.
2. Start MySQL. In phpMyAdmin, create an **empty** database named `marquez_pos`, select it, then import `database/marquez_pos.sql`. Do not import into an existing customer/users database. The SQL does not try to create the database, so it also works on shared hosts that restrict `CREATE DATABASE`.
3. Confirm `.env` matches your local database. Run `php spark serve` inside the project folder.
4. Open `http://localhost:8080/` and check `/customers`, `/users`, and `/about`.

If the extracted folder is placed inside XAMPP `htdocs` instead, set `app.baseURL` to the exact address where the site is accessed, such as `http://localhost/TFA3_JoseJhonPaulMarquez/`. The physical root `index.php` starts CodeIgniter, and the root `.htaccess` sends routes to it while serving CSS from `public/assets/`. Keep both `index.php` files. Apache rewrite must be enabled. The base URL must have **one scheme**, the correct path if installed in a subfolder, and **one trailing slash**. For instance, `app.baseURL = 'https://example.com/'`.

## Upload to a shared host

1. Create an empty database in your hosting control panel. Select **that** database in phpMyAdmin and import `database/marquez_pos.sql` once.
2. Upload the project with its `vendor/` folder. Prefer to serve the `public/` directory as the document root. When your host forces `htdocs`, upload the **contents** of the extracted project directly there: `htdocs/index.php`, `htdocs/.htaccess`, `htdocs/app/`, `htdocs/public/`, `htdocs/vendor/`, and the remaining project files. If the whole extracted folder sits inside `htdocs`, the domain root will still have no index file. Keep both `.htaccess` files and both `index.php` files.
3. Edit the uploaded `.env` using `env.hosting.example` as a guide. Set `app.baseURL` to your actual hosted URL, for example `https://your-domain.example/`, and set your **actual** hosting database host, full database name, username, and password. The ZIP contains only local placeholder values, not hosting credentials. Set `CI_ENVIRONMENT = production` and `database.default.DBDebug = false`.
4. Check all four routes on your live domain. If styles or links point to another host, correct `app.baseURL` in the uploaded `.env`. If records do not load, confirm the imported database matches the connection details.

## Routes and data

| Route | Purpose |
| --- | --- |
| `/` | POS home page and navigation |
| `/customers` | Five demonstration customer accounts from the `customers` table |
| `/users` | Five demonstration staff accounts from the `users` table |
| `/about` | Project explanation and Jose Jhon Paul Marquez credit |

The existing CodeIgniter models and controllers read the two database tables; views escape displayed values. `database/marquez_pos.sql` is the reproducible import file. The public design assets are in `public/assets/`. Never publish your actual `.env` credentials to a public repository.

PHP and MySQL were unavailable in the editing environment, so the hosted site still needs a browser and database check after you upload it.
