# Jose Jhon Paul Marquez | POS Directory

A CodeIgniter 4 directory for customer and user accounts. TFA3 adds validated create and edit forms and prepared avatar uploads. The included sample rows are demonstration data.

## Requirements

- PHP 8.2 or newer with `intl`, `mbstring`, `mysqli`, and GD extensions.
- MySQL or MariaDB.
- Composer if `vendor/` is not included.

## Database

`database/marquez_pos.sql` is the InfinityFree phpMyAdmin export supplied for this project. It contains the `customers` and `users` tables, including nullable `users.avatar`, and five example rows in each table. It does not contain a `role` column.

To make a fresh database, create an empty database in phpMyAdmin, select it, and import the SQL once. Do not import into an already populated database; the dump creates tables and inserts sample rows. The live InfinityFree database already contains these tables, so it does not need the SQL imported again.

## Local setup

1. Copy `.env.example` to `.env`.
2. Set the local `app.baseURL` and MySQL hostname, database, username, and password in `.env`.
3. If `vendor/` is missing, run `composer install` from this project folder.
4. Run `php spark serve` and open `http://localhost:8080/`.

## InfinityFree setup

Upload the project contents directly into the domain's document root, including `app/`, `public/`, `vendor/`, `writable/`, the root `index.php`, and the root `.htaccess`. Keep both `.htaccess` files and both `index.php` files.

Edit the private `.env` on the host: use `CI_ENVIRONMENT = production`, your exact HTTPS site URL with a trailing slash, and the host, database name, username, and password shown in the InfinityFree control panel. Never commit `.env` or real credentials to GitHub. The project ZIP intentionally excludes `.env`.

Create `public/assets/uploads/avatars/` on the host and ensure PHP can write to it. GD must be enabled for image resizing.

## TFA3 features

- `/customers`: list customers; **New Customer** creates one and **Edit** updates it. Full name and a valid email are required.
- `/users`: list users and avatars; **New User** creates one and **Edit** updates it and accepts an optional profile image. Username is required and unique; full name is required.
- Invalid forms return errors and the entered text. JPG and PNG avatar uploads are limited to 2 MB, resized to 240 by 240 pixels, stored in `public/assets/uploads/avatars/`, and only the generated filename is saved in `users.avatar`. A placeholder is used when no avatar is present.
- `/about`: project information.

## Submission

Publish the extracted project source and database export in the GitHub repository, then submit that repository link and your working hosted link. Use GitHub Desktop or Git from the extracted folder to publish the files. Do not upload the ZIP as the only repository file. Test the hosted create, edit, validation, and avatar features before submitting.
