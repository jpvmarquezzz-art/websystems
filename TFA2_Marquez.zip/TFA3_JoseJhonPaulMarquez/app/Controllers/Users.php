<?php
namespace App\Controllers;
use App\Models\UserModel;
use CodeIgniter\Exceptions\PageNotFoundException;
class Users extends BaseController
{
    public function index() { return view('users/index',['users'=>(new UserModel())->findAll()]); }
    public function newUser() { return view('users/form',['user'=>null,'errors'=>session()->getFlashdata('errors')??[]]); }
    public function create()
    {
        $data=$this->formData();
        $rules=['username'=>'required|max_length[50]|is_unique[users.username]','full_name'=>'required|max_length[100]'];
        if (!$this->validateData($data,$rules)) return redirect()->to(site_url('users/new'))->withInput()->with('errors',$this->validator->getErrors());
        $data['created_at']=date('Y-m-d H:i:s'); (new UserModel())->insert($data);
        return redirect()->to(site_url('users'))->with('success','User account created.');
    }
    public function edit(int $id)
    {
        $user=(new UserModel())->find($id);
        if ($user===null) throw PageNotFoundException::forPageNotFound();
        return view('users/form',['user'=>$user,'errors'=>session()->getFlashdata('errors')??[]]);
    }
    public function update(int $id)
    {
        $model=new UserModel();
        if ($model->find($id)===null) throw PageNotFoundException::forPageNotFound();
        $data=$this->formData();
        $rules=['username'=>'required|max_length[50]|is_unique[users.username,id,'.$id.']','full_name'=>'required|max_length[100]'];
        $editUrl=site_url('users/'.$id.'/edit');
        if (!$this->validateData($data,$rules)) return redirect()->to($editUrl)->withInput()->with('errors',$this->validator->getErrors());
        $avatar=$this->request->getFile('avatar');
        if ($avatar!==null && $avatar->getError()!==UPLOAD_ERR_NO_FILE) {
            $fileRules=['avatar'=>'max_size[avatar,2048]|is_image[avatar]|mime_in[avatar,image/jpeg,image/png]'];
            if (!$avatar->isValid() || !$this->validateData([],$fileRules)) return redirect()->to($editUrl)->withInput()->with('errors',['avatar'=>'Choose a valid JPG or PNG image no larger than 2 MB.']);
            $directory=FCPATH.'assets/uploads/avatars/';
            if (!is_dir($directory)||!is_writable($directory)) return redirect()->to($editUrl)->withInput()->with('errors',['avatar'=>'The avatar upload folder is missing or not writable.']);
            $extension=$avatar->getMimeType()==='image/png'?'.png':'.jpg';
            $filename=bin2hex(random_bytes(16)).$extension; $target=$directory.$filename;
            try {
                $saved=service('image')->withFile($avatar->getTempName())->fit(240,240)->save($target);
                if (!$saved) throw new \RuntimeException('Could not save prepared image.');
            } catch (\Throwable $e) {
                if (is_file($target)) unlink($target);
                log_message('error','Avatar preparation failed: '.$e->getMessage());
                return redirect()->to($editUrl)->withInput()->with('errors',['avatar'=>'The image could not be prepared. Please try another JPG or PNG.']);
            }
            $data['avatar']=$filename;
        }
        $model->update($id,$data);
        return redirect()->to(site_url('users'))->with('success','User account updated.');
    }
    private function formData(): array { return ['username'=>$this->textInput('username'),'full_name'=>$this->textInput('full_name')]; }
    private function textInput(string $name): string { $value=$this->request->getPost($name); return is_string($value)?trim($value):''; }
}
