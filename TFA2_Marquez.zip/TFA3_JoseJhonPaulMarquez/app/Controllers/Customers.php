<?php
namespace App\Controllers;
use App\Models\CustomerModel;
use CodeIgniter\Exceptions\PageNotFoundException;
class Customers extends BaseController
{
    public function index() { return view('customers/index', ['customers'=>(new CustomerModel())->findAll()]); }
    public function newCustomer() { return view('customers/form', ['customer'=>null,'errors'=>session()->getFlashdata('errors')??[]]); }
    public function create()
    {
        $data=$this->formData();
        $rules=['full_name'=>'required|max_length[100]','email'=>'required|valid_email|max_length[100]','phone'=>'permit_empty|max_length[20]'];
        if (!$this->validateData($data,$rules)) return redirect()->to(site_url('customers/new'))->withInput()->with('errors',$this->validator->getErrors());
        $data['created_at']=date('Y-m-d H:i:s'); (new CustomerModel())->insert($data);
        return redirect()->to(site_url('customers'))->with('success','Customer account created.');
    }
    public function edit(int $id)
    {
        $customer=(new CustomerModel())->find($id);
        if ($customer===null) throw PageNotFoundException::forPageNotFound();
        return view('customers/form',['customer'=>$customer,'errors'=>session()->getFlashdata('errors')??[]]);
    }
    public function update(int $id)
    {
        $model=new CustomerModel();
        if ($model->find($id)===null) throw PageNotFoundException::forPageNotFound();
        $data=$this->formData();
        $rules=['full_name'=>'required|max_length[100]','email'=>'required|valid_email|max_length[100]','phone'=>'permit_empty|max_length[20]'];
        if (!$this->validateData($data,$rules)) return redirect()->to(site_url('customers/'.$id.'/edit'))->withInput()->with('errors',$this->validator->getErrors());
        $model->update($id,$data);
        return redirect()->to(site_url('customers'))->with('success','Customer account updated.');
    }
    private function formData(): array { return ['full_name'=>$this->textInput('full_name'),'email'=>$this->textInput('email'),'phone'=>$this->textInput('phone')]; }
    private function textInput(string $name): string { $value=$this->request->getPost($name); return is_string($value)?trim($value):''; }
}
