<?= view('layouts/header', ['title' => 'Home | Jose Jhon Paul Marquez', 'active' => 'home']) ?>
<section class="page-heading page-heading--hero">
    <div>
        <p class="eyebrow">YOUR POS WORKSPACE / 01</p>
        <h1>Everything in<br><em>good order.</em></h1>
        <p class="intro">One clear place for the people behind every transaction. Browse customer accounts and staff records with ease.</p>
        <p class="hero-note">CODEIGNITER 4 &middot; DATABASE-POWERED DIRECTORY</p>
    </div>
</section>
<section class="feature-grid" aria-label="Explore account directories">
    <a class="card feature-card" href="<?= esc(site_url('customers'), 'attr') ?>">
        <p class="eyebrow">THE PEOPLE WE SERVE / 02</p>
        <h2>Customer accounts</h2>
        <p>Find names and contact details in one tidy directory.</p>
        <span class="arrow" aria-hidden="true">&rarr;</span>
    </a>
    <a class="card feature-card" href="<?= esc(site_url('users'), 'attr') ?>">
        <p class="eyebrow">THE PEOPLE BEHIND IT / 03</p>
        <h2>Staff accounts</h2>
        <p>See the team, their usernames, and their profile pictures.</p>
        <span class="arrow" aria-hidden="true">&rarr;</span>
    </a>
</section>
<?= view('layouts/footer') ?>
