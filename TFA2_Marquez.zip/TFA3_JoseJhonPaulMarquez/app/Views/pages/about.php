<?= view('layouts/header', ['title' => 'About | Jose Jhon Paul Marquez', 'active' => 'about']) ?>
<section class="page-heading"><div><p class="eyebrow">THE PURPOSE / 04</p><h1>Simple by design.</h1><p class="intro">A clear starting point for managing the people at the heart of a point-of-sale system.</p></div></section>
<section class="card about-card" aria-labelledby="developer-heading">
    <p class="eyebrow">DEVELOPED BY</p>
    <h2 id="developer-heading" class="developer-name">Jose Jhon Paul Marquez</h2>
    <p class="developer-signature">IT0049 &middot; CodeIgniter 4 POS project</p>
    <p>This application presents customer and staff accounts from a MySQL database through CodeIgniter models, controllers, and views. The directories are designed to make essential account information easy to find.</p>
    <p>The sample records are demonstration data. Update them in the database when using the application for a real project.</p>
    <div class="action-buttons"><a class="button" href="<?= esc(site_url('customers'), 'attr') ?>">Browse customers</a><a class="button button--secondary" href="<?= esc(site_url('users'), 'attr') ?>">Browse staff</a></div>
</section>
<?= view('layouts/footer') ?>
