<?php
$isEdit=$customer!==null;
$title=$isEdit?'Edit Customer':'New Customer';
$action=$isEdit?site_url('customers/'.$customer['id']):site_url('customers');
?>
<?= view('layouts/header',['title'=>$title.' | Jose Jhon Paul Marquez','active'=>'customers']) ?>
<section class="page-heading"><div><p class="eyebrow">CUSTOMER ACCOUNTS</p><h1><?= esc($title) ?></h1><p class="intro">Enter the customer's account details.</p></div></section>
<section class="card account-form-card">
<form action="<?= esc($action,'attr') ?>" method="post">
<?= csrf_field() ?>
<div class="form-field"><label for="full_name">Full name *</label>
<input id="full_name" name="full_name" type="text" maxlength="100" required value="<?= esc(old('full_name',$customer['full_name']??'',false),'attr') ?>">
<?php if(isset($errors['full_name'])): ?><p class="field-error"><?= esc($errors['full_name']) ?></p><?php endif ?></div>
<div class="form-field"><label for="email">Email *</label>
<input id="email" name="email" type="email" maxlength="100" required value="<?= esc(old('email',$customer['email']??'',false),'attr') ?>">
<?php if(isset($errors['email'])): ?><p class="field-error"><?= esc($errors['email']) ?></p><?php endif ?></div>
<div class="form-field"><label for="phone">Phone</label>
<input id="phone" name="phone" type="tel" maxlength="20" value="<?= esc(old('phone',$customer['phone']??'',false),'attr') ?>">
<?php if(isset($errors['phone'])): ?><p class="field-error"><?= esc($errors['phone']) ?></p><?php endif ?></div>
<div class="form-actions"><button class="button" type="submit"><?= $isEdit?'Save Changes':'Create Customer' ?></button>
<a class="button button--secondary" href="<?= esc(site_url('customers'),'attr') ?>">Cancel</a></div>
</form></section>
<?= view('layouts/footer') ?>
