<?= view('layouts/header',['title'=>'Customers | Jose Jhon Paul Marquez','active'=>'customers']) ?>
<section class="page-heading"><div><p class="eyebrow">THE PEOPLE WE SERVE / 02</p><h1>Customer directory.</h1><p class="intro">Keep account details close and easy to scan.</p></div></section>
<section class="card data-card" aria-labelledby="customers-heading">
<div class="table-heading"><p class="eyebrow">DATABASE RECORDS</p><h2 id="customers-heading">Customer accounts <span class="count"><?= count($customers) ?></span></h2>
<p>Names, email addresses, and contact numbers.</p>
<a class="button listing-button" href="<?= esc(site_url('customers/new'),'attr') ?>">New Customer</a></div>
<?php if($message=session()->getFlashdata('success')): ?><p class="success-message" role="status"><?= esc($message) ?></p><?php endif ?>
<?php if($customers===[]): ?>
<div class="empty-state" role="status"><h3>No customer accounts yet.</h3><p>Use New Customer to add the first account.</p></div>
<?php else: ?>
<div class="table-wrap" tabindex="0" role="region" aria-label="Customer accounts">
<table><caption class="sr-only">Customer account records</caption><thead><tr><th scope="col">Full name</th><th scope="col">Email</th><th scope="col">Phone</th><th scope="col">Action</th></tr></thead>
<tbody><?php foreach($customers as $customer): ?><tr>
<th scope="row"><?= esc($customer['full_name']) ?></th><td><?= esc($customer['email']) ?></td><td><?= esc($customer['phone']??'') ?></td>
<td><a href="<?= esc(site_url('customers/'.$customer['id'].'/edit'),'attr') ?>">Edit</a></td>
</tr><?php endforeach ?></tbody></table></div>
<?php endif ?>
</section>
<?= view('layouts/footer') ?>
