<?= view('layouts/header',['title'=>'Staff | Jose Jhon Paul Marquez','active'=>'users']) ?>
<section class="page-heading"><div><p class="eyebrow">THE PEOPLE BEHIND IT / 03</p><h1>Meet the team.</h1><p class="intro">An overview of the people who keep the shop running.</p></div></section>
<section class="card data-card" aria-labelledby="staff-heading">
<div class="table-heading"><p class="eyebrow">DATABASE RECORDS</p><h2 id="staff-heading">Staff accounts <span class="count"><?= count($users) ?></span></h2>
<p>Account usernames, full names, and profile pictures.</p>
<a class="button listing-button" href="<?= esc(site_url('users/new'),'attr') ?>">New User</a></div>
<?php if($message=session()->getFlashdata('success')): ?><p class="success-message" role="status"><?= esc($message) ?></p><?php endif ?>
<?php if($users===[]): ?>
<div class="empty-state" role="status"><h3>No staff accounts yet.</h3><p>Use New User to add the first account.</p></div>
<?php else: ?>
<div class="table-wrap" tabindex="0" role="region" aria-label="Staff accounts">
<table><caption class="sr-only">Staff account records</caption><thead><tr><th scope="col">Avatar</th><th scope="col">Username</th><th scope="col">Full name</th><th scope="col">Action</th></tr></thead>
<tbody><?php foreach($users as $user):
$filename=(string)($user['avatar']??'');
$hasAvatar=preg_match('/\A[a-f0-9]{32}\.(jpg|png)\z/',$filename)&&is_file(FCPATH.'assets/uploads/avatars/'.$filename);
$avatarUrl=$hasAvatar?base_url('assets/uploads/avatars/'.$filename):base_url('assets/avatar-placeholder.svg');
?><tr>
<td><img class="avatar-thumbnail" src="<?= esc($avatarUrl,'attr') ?>" alt="<?= $hasAvatar?esc('Avatar of '.$user['full_name'],'attr'):'Placeholder avatar' ?>" width="48" height="48"></td>
<td class="record-id">@<?= esc($user['username']) ?></td><th scope="row"><?= esc($user['full_name']) ?></th>
<td><a href="<?= esc(site_url('users/'.$user['id'].'/edit'),'attr') ?>">Edit</a></td>
</tr><?php endforeach ?></tbody></table></div>
<?php endif ?>
</section>
<?= view('layouts/footer') ?>
