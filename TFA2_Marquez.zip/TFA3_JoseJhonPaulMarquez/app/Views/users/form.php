<?php
$isEdit=$user!==null;
$title=$isEdit?'Edit User':'New User';
$action=$isEdit?site_url('users/'.$user['id']):site_url('users');
?>
<?= view('layouts/header',['title'=>$title.' | Jose Jhon Paul Marquez','active'=>'users']) ?>
<section class="page-heading"><div><p class="eyebrow">STAFF ACCOUNTS</p><h1><?= esc($title) ?></h1><p class="intro">Enter the staff member's account details.</p></div></section>
<section class="card account-form-card">
<form action="<?= esc($action,'attr') ?>" method="post" <?= $isEdit?'enctype="multipart/form-data"':'' ?>>
<?= csrf_field() ?>
<div class="form-field"><label for="username">Username *</label>
<input id="username" name="username" type="text" maxlength="50" required value="<?= esc(old('username',$user['username']??'',false),'attr') ?>">
<?php if(isset($errors['username'])): ?><p class="field-error"><?= esc($errors['username']) ?></p><?php endif ?></div>
<div class="form-field"><label for="full_name">Full name *</label>
<input id="full_name" name="full_name" type="text" maxlength="100" required value="<?= esc(old('full_name',$user['full_name']??'',false),'attr') ?>">
<?php if(isset($errors['full_name'])): ?><p class="field-error"><?= esc($errors['full_name']) ?></p><?php endif ?></div>
<?php if($isEdit): ?>
<div class="form-field"><label for="avatar">Profile picture</label>
<input id="avatar" name="avatar" type="file" accept=".jpg,.jpeg,.png,image/jpeg,image/png">
<p class="form-help">Optional. JPG or PNG, maximum 2 MB. Leave blank to keep the current picture.</p>
<?php if(isset($errors['avatar'])): ?><p class="field-error"><?= esc($errors['avatar']) ?></p><?php endif ?></div>
<?php endif ?>
<div class="form-actions"><button class="button" type="submit"><?= $isEdit?'Save Changes':'Create User' ?></button>
<a class="button button--secondary" href="<?= esc(site_url('users'),'attr') ?>">Cancel</a></div>
</form></section>
<?= view('layouts/footer') ?>
