<?= view('layouts/header', ['title' => 'Profile | Jose Jhon Paul Marquez', 'active' => 'profile']) ?>
<section class="page-heading"><div><p class="eyebrow">THE PERSON / 03</p><h1>Behind the work.</h1><p class="intro">Meet the person keeping this workspace moving.</p></div></section>
<section class="card profile-card" aria-labelledby="profile-heading">
    <?php if ($user === null): ?>
        <div class="empty-state" role="status"><h2 id="profile-heading">No profile available.</h2><p>The demo user has not been added to the database yet.</p></div>
    <?php else: ?>
        <div class="profile-intro">
            <div class="avatar" aria-hidden="true"><?= esc(mb_strtoupper(mb_substr($user['full_name'], 0, 1))) ?></div>
            <div><p class="eyebrow">WORKSPACE PROFILE</p><h2 id="profile-heading"><?= esc($user['full_name']) ?></h2><p class="muted">@<?= esc($user['username']) ?></p></div>
        </div>
        <dl class="detail-grid">
            <div><dt>Full name</dt><dd><?= esc($user['full_name']) ?></dd></div>
            <div><dt>Username</dt><dd><?= esc($user['username']) ?></dd></div>
            <div><dt>Email</dt><dd><?= esc($user['email']) ?></dd></div>
            <div><dt>Created at &middot; Manila time</dt><dd><?= esc($user['created_at']) ?></dd></div>
        </dl>
    <?php endif ?>
</section>
<?= view('layouts/footer') ?>
