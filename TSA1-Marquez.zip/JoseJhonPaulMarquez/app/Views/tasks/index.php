<?= view('layouts/header', ['title' => 'All tasks | Jose Jhon Paul Marquez', 'active' => 'tasks']) ?>
<section class="page-heading">
    <div><p class="eyebrow">THE BIG PICTURE / 02</p><h1>Everything in motion.</h1><p class="intro">Every task, from what is done to what is coming next.</p></div>
    <a class="button button--secondary" href="<?= esc(site_url('/'), 'attr') ?>">Back to today</a>
</section>
<section class="card" aria-labelledby="list-heading">
    <div class="section-heading">
        <div><p class="eyebrow">PAST / PRESENT / NEXT</p><h2 id="list-heading">All tasks <span class="count"><?= count($tasks) ?></span></h2></div>
        <span class="sort-label">Date &uarr; &nbsp; Oldest first</span>
    </div>
    <?= view('tasks/_table', ['tasks' => $tasks, 'caption' => 'All tasks ordered by date', 'emptyTitle' => 'No tasks have been recorded yet.', 'emptyMessage' => 'Tasks will appear here once they are added to the database.']) ?>
</section>
<?= view('layouts/footer') ?>
