<?= view('layouts/header', ['title' => 'About | Jose Jhon Paul Marquez', 'active' => 'about']) ?>
<section class="page-heading"><div><p class="eyebrow">THE IDEA / 04</p><h1>Clarity, one day at a time.</h1><p class="intro">A personal workspace for keeping the small details and big priorities in view.</p></div></section>
<section class="card about-card" aria-labelledby="developer-heading">
    <p class="eyebrow">Designed and developed by</p>
    <h2 id="developer-heading" class="developer-name">Jose Jhon Paul Marquez</h2>
    <p class="developer-signature">IT0049 &middot; Technical Summative Assessment 1</p>
    <p>Built with CodeIgniter 4 and a relational database, this workspace makes it easy to see what needs attention. Its pages demonstrate routes, controllers, models, and views working together.</p>
    <p>Today shows tasks due on the current date. All tasks presents the complete schedule, while Profile displays the workspace’s database-backed demo account.</p>
    <div class="action-buttons"><a class="button" href="<?= esc(site_url('/'), 'attr') ?>">See today's tasks</a><a class="button button--secondary" href="<?= esc(site_url('tasks'), 'attr') ?>">Browse all tasks</a></div>
</section>
<?= view('layouts/footer') ?>
