<?= view('layouts/header', ['title' => 'Today | Jose Jhon Paul Marquez', 'active' => 'home']) ?>
<section class="page-heading page-heading--hero">
    <div>
        <p class="eyebrow">YOUR DAILY WORKSPACE / 01</p>
        <h1>Make room for<br><em>what matters.</em></h1>
        <p class="intro">A little structure goes a long way. Here is what is on the calendar today.</p>
    </div>
    <p class="date-label"><span>THE DATE / MANILA TIME</span><time datetime="<?= esc($today, 'attr') ?>"><?= esc((new DateTimeImmutable($today))->format('F j, Y')) ?></time></p>
</section>
<section class="card" aria-labelledby="today-heading">
    <div class="section-heading">
        <div><p class="eyebrow">ON YOUR RADAR</p><h2 id="today-heading">Today’s lineup <span class="count"><?= count($tasks) ?></span></h2></div>
        <a class="text-link" href="<?= esc(site_url('tasks'), 'attr') ?>">View all tasks &rarr;</a>
    </div>
    <?= view('tasks/_table', ['tasks' => $tasks, 'caption' => 'Tasks scheduled for today', 'emptyTitle' => 'No tasks scheduled for today.', 'emptyMessage' => 'Your calendar is clear. Take a look at the complete task list for what is next.']) ?>
</section>
<p class="page-note">Only today’s tasks appear here. Explore the full list for past and upcoming work.</p>
<?= view('layouts/footer') ?>
