    </main>
    <footer class="site-footer">
        <span>MAKE TODAY COUNT<span class="footer-dot">.</span></span>
        <span>&copy; <?= esc(date('Y')) ?> Jose Jhon Paul Marquez</span>
    </footer>
</body>
</html>
