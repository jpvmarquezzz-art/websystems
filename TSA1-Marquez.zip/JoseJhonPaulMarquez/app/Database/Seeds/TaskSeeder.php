<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;
use CodeIgniter\I18n\Time;
use RuntimeException;

class TaskSeeder extends Seeder
{
    public function run()
    {
        if ($this->db->table('users')->countAllResults() > 1) {
            throw new RuntimeException('The workspace users table must contain exactly one demo user. Use a dedicated assessment database; this seeder will not delete existing users.');
        }

        $timezone = config('App')->appTimezone;
        $today = Time::today($timezone);
        $createdAt = Time::now($timezone)->toDateTimeString();
        $samples = [
            ['Review recent project milestones', 'completed', -1],
            ['Archive completed coursework notes', 'completed', -1],
            ['Check upcoming class deadlines', 'completed', 0],
            ['Prepare the project progress summary', 'in progress', 0],
            ['Review outstanding action items', 'pending', 0],
            ['Outline the next study session', 'pending', 1],
            ['Polish the project documentation', 'pending', 1],
            ['Back up the task database', 'pending', 1],
        ];

        $this->db->transStart();
        foreach ($samples as [$title, $status, $offset]) {
            $date = $today->addDays($offset)->toDateString();
            $existing = $this->db->table('tasks')->where('title', $title)->get()->getRowArray();
            if ($existing === null) {
                $this->db->table('tasks')->insert([
                    'title' => $title,
                    'status' => $status,
                    'task_date' => $date,
                    'created_at' => $createdAt,
                ]);
            } else {
                // Rerunning refreshes only sample dates, preserving status and creation time.
                $this->db->table('tasks')->where('id', $existing['id'])->update(['task_date' => $date]);
            }
        }

        if ($this->db->table('users')->countAllResults() === 0) {
            // This sample profile matches the workspace owner.
            $this->db->table('users')->insert([
                'username' => 'josemarquez',
                'full_name' => 'Jose Jhon Paul Marquez',
                'email' => 'jose.marquez@example.com',
                'created_at' => $createdAt,
            ]);
        }
        $this->db->transComplete();

        if ($this->db->transStatus() === false) {
            throw new RuntimeException('Seeding failed; the database transaction was rolled back.');
        }
    }
}
