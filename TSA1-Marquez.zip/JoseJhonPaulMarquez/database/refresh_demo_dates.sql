-- Optional: refresh the eight sample dates immediately BEFORE demonstrating.
-- Run only in the dedicated marquez_daily demo database; real task dates should not be reset.
-- This updates the supplied sample titles only. It creates or deletes no records.
SET @tsa_today = DATE(DATE_ADD(UTC_TIMESTAMP(), INTERVAL 8 HOUR));
UPDATE tasks SET task_date = DATE_SUB(@tsa_today, INTERVAL 1 DAY)
WHERE title IN ('Review recent project milestones', 'Archive completed coursework notes');
UPDATE tasks SET task_date = @tsa_today
WHERE title IN ('Check upcoming class deadlines', 'Prepare the project progress summary', 'Review outstanding action items');
UPDATE tasks SET task_date = DATE_ADD(@tsa_today, INTERVAL 1 DAY)
WHERE title IN ('Outline the next study session', 'Polish the project documentation', 'Back up the task database');
