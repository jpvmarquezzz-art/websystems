-- Jose Jhon Paul Marquez — Daily Workspace - IT0049 Technical Summative Assessment 1
-- Choose a NEW EMPTY database in phpMyAdmin before importing.
-- This creates the exact assessment tables and initial data.
-- Use this import OR migrations + TaskSeeder, not both.
-- No database name or hosting credentials are embedded here.

CREATE TABLE tasks (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(150) NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'pending',
  task_date DATE NOT NULL,
  created_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  full_name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL,
  created_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Asia/Manila is UTC+08:00. This avoids depending on the DB server timezone.
SET @tsa_now = DATE_ADD(UTC_TIMESTAMP(), INTERVAL 8 HOUR);
SET @tsa_today = DATE(@tsa_now);

START TRANSACTION;
INSERT INTO tasks (title, status, task_date, created_at) VALUES
('Review recent project milestones', 'completed', DATE_SUB(@tsa_today, INTERVAL 1 DAY), @tsa_now),
('Archive completed coursework notes', 'completed', DATE_SUB(@tsa_today, INTERVAL 1 DAY), @tsa_now),
('Check upcoming class deadlines', 'completed', @tsa_today, @tsa_now),
('Prepare the project progress summary', 'in progress', @tsa_today, @tsa_now),
('Review outstanding action items', 'pending', @tsa_today, @tsa_now),
('Outline the next study session', 'pending', DATE_ADD(@tsa_today, INTERVAL 1 DAY), @tsa_now),
('Polish the project documentation', 'pending', DATE_ADD(@tsa_today, INTERVAL 1 DAY), @tsa_now),
('Back up the task database', 'pending', DATE_ADD(@tsa_today, INTERVAL 1 DAY), @tsa_now);

INSERT INTO users (username, full_name, email, created_at) VALUES
('josemarquez', 'Jose Jhon Paul Marquez', 'jose.marquez@example.com', @tsa_now);
COMMIT;
