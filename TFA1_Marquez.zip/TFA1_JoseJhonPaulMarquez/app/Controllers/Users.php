<?php

namespace App\Controllers;

class Users extends BaseController
{
    public function index(): string
    {
        // Static sample data for the first POS activity; no database is required.
        $data['users'] = [
            ['username' => 'josemarquez', 'full_name' => 'Jose Jhon Paul Marquez', 'role' => 'Administrator'],
            ['username' => 'alexa.ramos', 'full_name' => 'Alexa Ramos', 'role' => 'Cashier'],
            ['username' => 'ivan.garcia', 'full_name' => 'Ivan Garcia', 'role' => 'Cashier'],
            ['username' => 'dana.flores', 'full_name' => 'Dana Flores', 'role' => 'Store Manager'],
            ['username' => 'leo.navarro', 'full_name' => 'Leo Navarro', 'role' => 'Sales Staff'],
        ];

        return view('users/index', $data);
    }
}
