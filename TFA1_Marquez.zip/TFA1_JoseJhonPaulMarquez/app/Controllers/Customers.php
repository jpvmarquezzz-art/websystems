<?php

namespace App\Controllers;

class Customers extends BaseController
{
    public function index(): string
    {
        // Static sample data for the first POS activity; no database is required.
        $data['customers'] = [
            ['full_name' => 'Mara Santos', 'email' => 'mara.santos@example.com', 'phone' => '09000000001'],
            ['full_name' => 'Nico Reyes', 'email' => 'nico.reyes@example.com', 'phone' => '09000000002'],
            ['full_name' => 'Lia Cruz', 'email' => 'lia.cruz@example.com', 'phone' => '09000000003'],
            ['full_name' => 'Paolo Dela Rosa', 'email' => 'paolo.delarosa@example.com', 'phone' => '09000000004'],
            ['full_name' => 'Ava Mendoza', 'email' => 'ava.mendoza@example.com', 'phone' => '09000000005'],
        ];

        return view('customers/index', $data);
    }
}
