<?= view('layouts/header', ['title' => 'Customers | Jose Jhon Paul Marquez', 'active' => 'customers']) ?>
<section class="page-heading"><div><p class="eyebrow">THE PEOPLE WE SERVE / 02</p><h1>Customer directory.</h1><p class="intro">Keep account details close and easy to scan.</p></div></section>
<section class="card data-card" aria-labelledby="customers-heading">
    <div class="table-heading"><p class="eyebrow">SAMPLE RECORDS</p><h2 id="customers-heading">Customer accounts <span class="count"><?= count($customers) ?></span></h2><p>Names, email addresses, and contact numbers.</p></div>
    <?php if ($customers === []): ?>
        <div class="empty-state" role="status"><h3>No customer accounts yet.</h3><p>Add sample customers to the Customers controller to display them here.</p></div>
    <?php else: ?>
        <div class="table-wrap" tabindex="0" role="region" aria-label="Customer accounts">
            <table><caption class="sr-only">Customer account records</caption><thead><tr><th scope="col">Full name</th><th scope="col">Email</th><th scope="col">Phone</th></tr></thead>
            <tbody><?php foreach ($customers as $customer): ?><tr><th scope="row"><?= esc($customer['full_name']) ?></th><td><?= esc($customer['email']) ?></td><td><?= esc($customer['phone'] ?? '') ?></td></tr><?php endforeach ?></tbody></table>
        </div>
    <?php endif ?>
</section>
<?= view('layouts/footer') ?>
