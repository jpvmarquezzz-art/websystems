<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#101a2a">
    <title><?= esc($title ?? 'Jose Jhon Paul Marquez') ?></title>
    <link rel="icon" href="<?= esc(base_url('assets/favicon.svg'), 'attr') ?>" type="image/svg+xml">
    <link rel="stylesheet" href="<?= esc(base_url('assets/css/app.css'), 'attr') ?>">
</head>
<body>
    <a class="skip-link" href="#main-content">Skip to content</a>
    <header class="site-header">
        <a class="brand" href="<?= esc(site_url('/'), 'attr') ?>">
            <span class="brand-mark" aria-hidden="true">JM<span class="brand-dot">.</span></span>
            <span>Jose Jhon Paul Marquez<small>POINT OF SALE / DIRECTORY</small></span>
        </a>
        <nav aria-label="Main navigation">
            <?php foreach (['home' => ['/', 'Home'], 'customers' => ['customers', 'Customers'], 'users' => ['users', 'Staff'], 'about' => ['about', 'About']] as $key => [$path, $label]): ?>
                <a <?= ($active ?? '') === $key ? 'class="active" aria-current="page"' : '' ?> href="<?= esc(site_url($path), 'attr') ?>"><?= esc($label) ?></a>
            <?php endforeach ?>
        </nav>
    </header>
    <main id="main-content">
