    </main>
    <footer class="site-footer">
        <span>BETTER RECORDS<span class="footer-dot">.</span> BETTER SERVICE.</span>
        <span>&copy; <?= esc(date('Y')) ?> Jose Jhon Paul Marquez</span>
    </footer>
</body>
</html>
