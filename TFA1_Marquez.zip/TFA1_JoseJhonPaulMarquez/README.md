# TFA1 POS Directory — Jose Jhon Paul Marquez

A four-page CodeIgniter 4 Point-of-Sale starter project adapted from the supplied TFA3 ZIP to meet the TFA1 laboratory activity. Customer and user accounts come from **static PHP arrays in their respective controllers**. Running these four pages does not require MySQL.

## Requirements and local setup

- PHP 8.2 or newer with the extensions required by CodeIgniter 4 (including `intl` and `mbstring`), and Composer if you need to install dependencies. The ZIP includes `vendor/` from the supplied project.
- Extract the archive and open the project folder in a terminal.
- If `vendor/` is absent, run `composer install` inside the project folder.
- Review `.env` and set `app.baseURL` to your exact local URL, with a trailing slash. For `php spark serve`, the included value is `http://localhost:8080/`.
- Run `php spark serve` and open `http://localhost:8080/`. Visit every route listed below.

| Route | Controller method | Page content |
| --- | --- | --- |
| `/` | `Pages::index` | Landing page and links to the directories |
| `/about` | `Pages::about` | Project purpose and author |
| `/customers` | `Customers::index` | Five customers: full name, email, phone |
| `/users` | `Users::index` | Five staff: username, full name, role |

`app/Config/Routes.php` defines the four routes. `app/Controllers/Customers.php` and `app/Controllers/Users.php` define sample arrays and pass them to views. The views under `app/Views/` use `foreach` and `esc()` to display the records. Navigation in `app/Views/layouts/header.php` links all four pages.

## Hosting

Prefer serving the `public/` directory as the document root. If the host requires `htdocs` as the document root, upload the **contents of the project folder** directly into `htdocs`, including root `index.php`, `.htaccess`, `app/`, `public/`, and `vendor/`. The supplied root entry point and rewrite rules support that arrangement. Ensure Apache rewriting and PHP 8.2+ are available. On the host, set `.env` values as shown in `env.hosting.example`: use the exact deployed HTTPS URL, including its trailing slash, and set `CI_ENVIRONMENT = production`. A mismatched base URL causes navigation to point at the wrong site. No database import or credentials are required for this version.

## Submission

The activity asks for both a GitHub repository link with raw project files (including a database export) and a working hosted link. The `database/marquez_pos.sql` file is retained from the source project solely for that export requirement; **the TFA1 application does not read it**. Upload this project to your repository and host, test all four live routes, then submit the two real URLs. Do not publish a `.env` containing credentials. GitHub and hosting URLs cannot be supplied by this ZIP itself.
