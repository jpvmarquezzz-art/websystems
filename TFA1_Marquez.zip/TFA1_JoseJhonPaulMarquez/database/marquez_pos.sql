-- Archived export from the supplied TFA3 project for the TFA1 submission requirement.
-- The TFA1 site uses static controller arrays; importing this SQL is NOT required.
-- Jose Jhon Paul Marquez | POS directory demo data
-- In phpMyAdmin, SELECT AN EMPTY DATABASE FIRST, then import this file.
-- The script does not create or switch databases, for compatibility with shared hosts.
-- Run once on an empty database; do not reimport into populated tables.
CREATE TABLE customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    created_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    created_at DATETIME NOT NULL,
    role VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO customers (full_name, email, phone, created_at) VALUES
    ('Mara Santos', 'mara.santos@example.com', '09000000001', '2026-10-11 09:00:00'),
    ('Nico Reyes', 'nico.reyes@example.com', '09000000002', '2026-10-11 09:05:00'),
    ('Lia Cruz', 'lia.cruz@example.com', '09000000003', '2026-10-11 09:10:00'),
    ('Paolo Dela Rosa', 'paolo.delarosa@example.com', '09000000004', '2026-10-11 09:15:00'),
    ('Ava Mendoza', 'ava.mendoza@example.com', '09000000005', '2026-10-11 09:20:00');

INSERT INTO users (username, full_name, created_at, role) VALUES
    ('josemarquez', 'Jose Jhon Paul Marquez', '2026-10-11 09:00:00', 'Administrator'),
    ('alexa.ramos', 'Alexa Ramos', '2026-10-11 09:05:00', 'Cashier'),
    ('ivan.garcia', 'Ivan Garcia', '2026-10-11 09:10:00', 'Cashier'),
    ('dana.flores', 'Dana Flores', '2026-10-11 09:15:00', 'Store Manager'),
    ('leo.navarro', 'Leo Navarro', '2026-10-11 09:20:00', 'Sales Staff');
